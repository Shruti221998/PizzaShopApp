import React from 'react';

const PizzaOrderStages = ({ orderId, currentStage, onStageChange, orderTime }) => {
  return (
    <div>
      <h2>Order ID: {orderId}</h2>
      <p>Current Stage: {currentStage}</p>
      <p>Time Spent in Current Stage: {orderTime} minutes</p>
      <button onClick={onStageChange} disabled={currentStage === 'Order Picked'}>
        Next Stage
      </button>
    </div>
  );
};

export default PizzaOrderStages;
