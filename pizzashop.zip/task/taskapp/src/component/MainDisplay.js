import React from 'react';

const MainDisplay = ({ orders, deliveredCount, onMoveToNextStage, onCancelOrder }) => {
  return (
    <div>
      <h2>Main Display</h2>
      <p>Total Pizzas Delivered Today: {deliveredCount}</p>
      <table style={{ width: '100%' }}>
        <thead>
          <tr>
            <th>Order Id</th>
            <th>Stage</th>
            <th>Total Time Spent</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order) => (
            <tr key={order.id}>
              <td>{order.id}</td>
              <td>{order.stage}</td>
              <td>{formatTime(order.orderTime || 0)}</td>
              <td>{renderAction(order, onMoveToNextStage, onCancelOrder)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const formatTime = (totalMinutes) => {
  const minutes = Math.floor(totalMinutes);
  const seconds = Math.floor((totalMinutes - minutes) * 60);
  return `${minutes} min ${seconds} sec`;
};

const renderAction = (order, onMoveToNextStage, onCancelOrder) => {
  if (order.stage === 'Order Ready') {
    return <button onClick={() => onMoveToNextStage(order.id)}>Mark as Picked</button>;
  } else if (order.stage !== 'Order Picked') {
    return (
      <>
        <button onClick={() => onMoveToNextStage(order.id)}>Next Stage</button>
        <button onClick={() => onCancelOrder(order.id)} style={{ marginLeft: '10px', color: 'red' }}>
          Cancel Order
        </button>
      </>
    );
  } else {
    return null; // No action button for "Order Picked"
  }
};

export default MainDisplay;
