import React, { useState } from 'react';

const PizzaOrderForm = ({ ordersCount, onOrderPlaced }) => {
  const [pizzaType, setPizzaType] = useState('');
  const [pizzaSize, setPizzaSize] = useState('');
  const [pizzaBase, setPizzaBase] = useState('');

  const handleTypeChange = (event) => {
    setPizzaType(event.target.value);
  };

  const handleSizeChange = (event) => {
    setPizzaSize(event.target.value);
  };

  const handleBaseChange = (event) => {
    setPizzaBase(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (ordersCount >= 10) {
      alert('Not taking any more orders for now');
      return;
    }

    // Process the pizza order with the selected options
    const order = {
      type: pizzaType,
      size: pizzaSize,
      base: pizzaBase,
    };

    // You can add logic here to submit the order to a server or perform further actions
    onOrderPlaced(order);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>
          Type:
          <select value={pizzaType} onChange={handleTypeChange}>
            <option value="">Select</option>
            <option value="veg">Veg</option>
            <option value="nonVeg">Non-Veg</option>
          </select>
        </label>
      </div>

      <div>
        <label>
          Size:
          <select value={pizzaSize} onChange={handleSizeChange}>
            <option value="">Select</option>
            <option value="large">Large</option>
            <option value="medium">Medium</option>
            <option value="small">Small</option>
          </select>
        </label>
      </div>

      <div>
        <label>
          Base:
          <select value={pizzaBase} onChange={handleBaseChange}>
            <option value="">Select</option>
            <option value="thin">Thin</option>
            <option value="thick">Thick</option>
          </select>
        </label>
      </div>

      <button type="submit">Place Order</button>
    </form>
  );
};

export default PizzaOrderForm;