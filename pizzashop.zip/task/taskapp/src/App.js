import React, { useState, useEffect } from 'react';
import PizzaOrderForm from './component/PizzaOrderForm'
import PizzaOrderStages from './component/PizzaOrderStages';
import MainDisplay from './component/MainDisplay';

const App = () => {
  const [orders, setOrders] = useState([]);
  const [ordersCount, setOrdersCount] = useState(0);
  const [deliveredCount, setDeliveredCount] = useState(0);

  const handleOrderPlaced = (order) => {
  setOrders((prevOrders) => {
    const prevCount = prevOrders.length; // Declare prevCount here
    return [
      ...prevOrders,
      {
        id: `00${prevCount + 1}`,
        order,
        stage: 'Order Placed',
        startTime: new Date(),
      },
    ];
  });
};

  const calculateMakingTime = (size) => {
    switch (size) {
      case 'Small':
        return 3; // 3 minutes for Small pizza
      case 'Medium':
        return 4; // 4 minutes for Medium pizza
      case 'Large':
        return 5; // 5 minutes for Large pizza
      default:
        return 0; // Default to 0 minutes for unknown sizes
    }
  };

  const handleStageChange = (orderId) => {
    setOrders((prevOrders) =>
      prevOrders.map((order) => {
        if (order.id === orderId) {
          const nextStage = getNextStage(order.stage);
          if (nextStage === 'Order Picked') {
            setDeliveredCount((prevDeliveredCount) => prevDeliveredCount + 1);
          }
          return {
            ...order,
            stage: nextStage,
            startTime: new Date(),
          };
        }
        return order;
      })
    );
  };

  const handleOrderCancel = (orderId) => {
    setOrders((prevOrders) =>
      prevOrders.filter((order) => {
        if (order.id === orderId && order.stage !== 'Order Ready') {
          setOrdersCount((prevCount) => prevCount - 1);
        }
        return order.id !== orderId;
      })
    );
  };

  const handleOrderPicked = (orderId) => {
    setOrders((prevOrders) =>
      prevOrders.map((order) =>
        order.id === orderId
          ? {
              ...order,
              stage: 'Order Picked',
              startTime: new Date(),
            }
          : order
      )
    );
  };

  const getNextStage = (currentStage) => {
    switch (currentStage) {
      case 'Order Placed':
        return 'Order in Making';
      case 'Order in Making':
        return 'Order Ready';
      case 'Order Ready':
        return 'Order Picked';
      default:
        return currentStage;
    }
  };

  useEffect(() => {
    const intervalId = setInterval(() => {
      setOrders((prevOrders) =>
        prevOrders.map((order) => ({
          ...order,
          orderTime: Math.floor((new Date() - order.startTime) / (1000 * 60)),
        }))
      );
    }, 1000); // Update every second

    return () => clearInterval(intervalId);
  }, []);

  const handleMoveToNextStage = (orderId) => {
    handleStageChange(orderId);
  };

  const handleCancelOrder = (orderId) => {
    handleOrderCancel(orderId);
  };

  return (
    <div>
      <h1>Pizza Order App</h1>
      <div>
      <h2>Pizza Order Form</h2>
      {ordersCount < 10 ? (
        <div>
          <PizzaOrderForm ordersCount={ordersCount} onOrderPlaced={handleOrderPlaced} />
        </div>
      ) : (
        <p>Not taking any more orders for now</p>
      )}
      </div>
      
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <div style={{ flex: 1 }}>
          <h2>Pizza Stages Section</h2>
          {orders.map((order) => (
            <div key={order.id}>
              <PizzaOrderStages
                orderId={order.id}
                currentStage={order.stage}
                orderTime={order.orderTime || 0}
                onStageChange={() => handleStageChange(order.id)}
                onPicked={() => handleOrderPicked(order.id)}
                onCancel={() => handleOrderCancel(order.id)}
              />
            </div>
          ))}
        </div>
        <div style={{ flex: 1 }}>
          <MainDisplay
            orders={orders}
            deliveredCount={deliveredCount}
            onMoveToNextStage={handleMoveToNextStage}
            onCancelOrder={handleCancelOrder}
          />
        </div>
      </div>
      
    </div>
  );
};

export default App;
